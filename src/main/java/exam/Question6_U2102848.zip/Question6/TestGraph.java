package exam.Question6;

import java.util.ArrayList;

public class TestGraph {
    public static void main(String[] args) {
        RoutingGraph<String, Double> graph = new RoutingGraph<>();
        String [] locations = {"A", "B", "C", "D", "E", "F", "G"};
        for(String location: locations)
            graph.addVertex(location);

        System.out.println("The number of vertices in MyCityGraph: " + graph.getSize());

        System.out.println("List all vertices:");
        ArrayList<String> vertices = graph.getVertex();
        for (int i = 0; i < vertices.size(); i++){
            System.out.print(i + ": " + vertices.get(i) + "\t");
        }
        System.out.println();

        // adding edges
        graph.addEdge("A", "C", 10.1);
        graph.addEdge("A", "B", 7.0);
        graph.addEdge("B", "A", 7.0);
        graph.addEdge("B", "C", 5.5);
        graph.addEdge("C", "B", 5.5);
        graph.addEdge("B", "E", 3.2);
        graph.addEdge("C", "D", 8.3);
        graph.addEdge("E", "D", 2.9);
        graph.addEdge("E", "G", 6.0);
        graph.addEdge("G", "E", 6.0);
        graph.addEdge("E", "F", 4.0);
        graph.addEdge("D", "G", 4.9);
        graph.addEdge("F", "G", 2.3);

        System.out.println("Has edge from B TO A? " + graph.hasEdge("B", "A"));
        System.out.println("Has edge from A TO D? " + graph.hasEdge("A", "D"));

        System.out.println(graph.getNeighbours("A"));
    }
}
